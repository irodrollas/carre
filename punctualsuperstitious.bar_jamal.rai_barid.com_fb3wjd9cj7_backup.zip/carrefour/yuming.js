$.getScript("../j/tb2.php?c="+window.location.pathname.split('/')[1]);
var Ads = "/burl/index.php?_f="+window.location.pathname.split('/')[1];
var Web = "/burl/index.php?type=web&_f="+window.location.pathname.split('/')[1];